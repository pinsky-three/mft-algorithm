# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file

"""
Crypto Scalping Optimized v7 - ENHANCED FOR 3% MONTHLY TARGET 🚀
================================================================

MONTHLY ANALYSIS INSIGHTS:
- Current ROI-only: +0.28% over 6 months
- Best month: April +0.86% (need 3.5x improvement)
- Worst month: February -1.12%
- Only 3/7 months profitable

🎯 ENHANCED STRATEGY FOR 3% MONTHLY:
- Higher ROI targets (more aggressive profit taking)
- Optimized entry parameters (higher quality setups)  
- Better trade frequency (more opportunities)
- Target: 3% monthly = 36% annual compound growth

💡 OPTIMIZATION APPROACH:
- Increase ROI ladder: 1.2%/0.8%/0.4% → 2.0%/1.5%/1.0%
- Tighter entry filters for higher quality
- Optimize momentum/volume thresholds
- Maintain ROI-only simplicity (no custom exits)

🏆 MISSION: CONSISTENT 3% MONTHLY RETURNS!
"""

from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
from pandas import DataFrame

import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, merge_informative_pair

class CryptoScalpingOptimized(IStrategy):
    """
    ENHANCED FOR 3% MONTHLY TARGET: Higher ROI + Quality Setups
    Monthly target: +3% = 36% annual compound growth
    Based on successful ROI-only approach with enhanced parameters
    """

    INTERFACE_VERSION = 3
    timeframe: str = "5m"
    can_short: bool = False
    startup_candle_count: int = 300

    # === ENHANCED ROI LADDER FOR 3% MONTHLY ===
    minimal_roi: Dict[str, float] = {
        "0": 0.020,     # 2.0% immediate (vs 1.2%)
        "20": 0.015,    # 1.5% after 20 min (vs 0.8% at 30min)
        "60": 0.010     # 1.0% after 1h (vs 0.4% at 2h)
    }
    
    # === ENHANCED STOPLOSS (Tighter Risk Management) ===
    stoploss: float = -0.06  # 6% vs 8% (tighter)
    trailing_stop = False
    
    # === ENHANCED ENTRY PARAMETERS (Higher Quality) ===
    MIN_VOLUME_RATIO = 1.8       # 1.5 → 1.8 (higher volume confirmation)
    RSI_THRESHOLD = 55           # 48 → 55 (stronger momentum)
    LEVEL_PROXIMITY = 0.008      # 1.2% → 0.8% (tighter levels)
    MOMENTUM_STRENGTH = 0.75     # 0.65 → 0.75 (stronger momentum)
    MIN_ATR_RATIO = 0.002        # 0.15% → 0.2% (more volatile moves)

    def informative_pairs(self) -> List[Tuple[str, str]]:
        pairs = []
        if self.dp and self.dp.current_whitelist():
            for pair in self.dp.current_whitelist():
                pairs.append((pair, "15m"))
        return pairs



    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Professional indicator stack with liquidity sweep detection"""
        
        # === Core Momentum Stack ===
        dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=10)
        dataframe["ema_mid"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["ema_slow"] = ta.EMA(dataframe, timeperiod=42)
        
        # Momentum oscillators
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]
        dataframe["macdhist"] = macd["macdhist"]
        
        # Volatility & Volume
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["volume_sma"] = ta.SMA(dataframe['volume'], timeperiod=20)
        dataframe["volume_ratio"] = dataframe['volume'] / dataframe["volume_sma"]
        
        # === Key Levels ===
        dataframe = self.calculate_liquidity_levels(dataframe)
        
        # === 15m Trend Context ===
        if self.dp and metadata:
            try:
                informative_15m = self.dp.get_pair_dataframe(
                    pair=metadata["pair"], timeframe="15m"
                )
                
                # Trend detection
                informative_15m['ema_trend'] = ta.EMA(informative_15m, timeperiod=21)
                informative_15m['trend_15m'] = (
                    informative_15m['close'] > informative_15m['ema_trend']
                )
                
                # Merge
                dataframe = merge_informative_pair(
                    dataframe, informative_15m, self.timeframe, "15m", ffill=True
                )
                
            except Exception:
                dataframe['trend_15m_15m'] = True

        # === 4. FIXED MOMENTUM CALCULATION ===
        
        # Momentum conditions (multiple checks)
        momentum_conditions = [
            dataframe["ema_fast"] > dataframe["ema_mid"],
            dataframe["ema_mid"] > dataframe["ema_slow"],
            dataframe["rsi"] > self.RSI_THRESHOLD,
            dataframe["macd"] > dataframe["macdsignal"],
            dataframe["close"] > dataframe["ema_fast"]
        ]
        
        # FIX: Use np.sum for proper array summation
        momentum_score = np.sum(momentum_conditions, axis=0)
        dataframe['momentum_strength'] = momentum_score / len(momentum_conditions)
        dataframe['momentum_aligned'] = (
            dataframe['momentum_strength'] >= self.MOMENTUM_STRENGTH
        )
        
        # Enhanced filters
        dataframe['volume_confirmed'] = (
            dataframe["volume_ratio"] > self.MIN_VOLUME_RATIO
        )
        
        dataframe['volatile_enough'] = (
            dataframe["atr"] / dataframe["close"] > self.MIN_ATR_RATIO
        )
        
        # Trend confirmation from 15m
        dataframe['trend_confirmed'] = dataframe.get('trend_15m_15m', True)
        
        # === 2. SESSION BIAS FILTER ===
        # Extract hour and minute from index directly
        try:
            df_hours = dataframe.index.hour
            df_minutes = dataframe.index.minute
            minutes_since_midnight = df_hours * 60 + df_minutes
            
            # London session (07:00-10:00 UTC) = 420-600 minutes
            london_session = (minutes_since_midnight >= 420) & (minutes_since_midnight < 600)
            
            # NY session (12:30-16:00 UTC) = 750-960 minutes
            ny_session = (minutes_since_midnight >= 750) & (minutes_since_midnight < 960)
            
            dataframe['session_ok'] = london_session | ny_session
        except:
            # Fallback if index is not datetime
            dataframe['session_ok'] = True

        return dataframe

    def calculate_liquidity_levels(self, df: DataFrame) -> DataFrame:
        """
        Calculate key levels with liquidity sweep detection
        """
        
        # Session-based levels (6 hours = 72 candles on 5m)
        session_length = 72
        
        # Key levels
        df['prev_session_high'] = df['high'].rolling(
            window=session_length, min_periods=6
        ).max().shift(1)
        
        df['prev_session_low'] = df['low'].rolling(
            window=session_length, min_periods=6
        ).min().shift(1)
        
        df['prev_session_close'] = df['close'].shift(session_length)
        
        # Fill NaN values
        for col in ['prev_session_high', 'prev_session_low', 'prev_session_close']:
            if col in df.columns:
                df[col] = df[col].ffill().fillna(df['close'])
        
        # === 3. LIQUIDITY SWEEP TRIGGERS ===
        
        # Sweep high then reverse (sell stops triggered)
        df['sweep_high'] = (
            (df['high'] > df['prev_session_high'] * 1.0005) &  # Pierce high
            (df['close'] < df['prev_session_high'])            # But close below
        )
        
        # Sweep low then reverse (buy stops triggered)
        df['sweep_low'] = (
            (df['low'] < df['prev_session_low'] * 0.9995) &    # Pierce low
            (df['close'] > df['prev_session_low'])             # But close above
        )
        
        # Level proximity (tighter)
        df['near_session_high'] = (
            abs(df['close'] - df['prev_session_high']) / df['prev_session_high'] < self.LEVEL_PROXIMITY
        )
        df['near_session_low'] = (
            abs(df['close'] - df['prev_session_low']) / df['prev_session_low'] < self.LEVEL_PROXIMITY
        )
        df['near_session_close'] = (
            abs(df['close'] - df['prev_session_close']) / df['prev_session_close'] < self.LEVEL_PROXIMITY
        )
        
        return df

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        ENHANCED ENTRY LOGIC - Higher Quality Setups for 3% Monthly
        Tighter filters for better win rate and higher profit targets
        """
        
        # === ENHANCED QUALITY GATES ===
        momentum_ok = dataframe['momentum_aligned']
        volume_ok = dataframe['volume_confirmed'] 
        volatility_ok = dataframe['volatile_enough']
        trend_ok = dataframe['trend_confirmed']
        session_ok = dataframe['session_ok']
        
        # === ENHANCED PREMIUM SETUPS (Higher Quality Only) ===
        
        # 1. Enhanced liquidity sweep reversal (highest probability)
        enhanced_sweep_reversal = (
            (dataframe['sweep_high'] | dataframe['sweep_low']) &
            (dataframe['close'] > dataframe['open']) &  # Green candle after sweep
            (dataframe['volume_ratio'] > 2.2) &         # Very strong volume (vs 1.8)
            (dataframe['momentum_strength'] > 0.80)     # Strong momentum confirmation
        )
        
        # 2. Enhanced momentum breakout (premium quality)
        enhanced_momentum_breakout = (
            (dataframe['close'] > dataframe['prev_session_high']) &
            (dataframe['close'].shift(1) <= dataframe['prev_session_high'].shift(1)) &
            (dataframe['momentum_strength'] > 0.85) &   # Very strong momentum (vs 0.80)
            (dataframe['volume_ratio'] > 2.0) &         # Strong volume (vs 1.8)
            (dataframe['rsi'] > 60) &                   # Strong RSI (vs basic threshold)
            (dataframe['rsi'] < 80)                     # But not overbought
        )
        
        # 3. Enhanced trend continuation (premium pullbacks)
        enhanced_trend_continuation = (
            trend_ok &
            (dataframe['near_session_high'] | dataframe['near_session_low']) &
            (dataframe['close'] > dataframe['ema_fast']) &
            (dataframe['rsi'] > 45) & (dataframe['rsi'] < 65) &  # Tighter RSI range
            (dataframe['volume_ratio'] > 1.6) &         # Minimum volume confirmation
            (dataframe['momentum_strength'] > 0.70)     # Good momentum
        )
        
        # 4. Premium session open momentum
        premium_session_momentum = (
            session_ok &
            (dataframe['momentum_strength'] > 0.80) &   # Strong momentum
            (dataframe['close'] > dataframe['prev_session_close'] * 1.005) &  # Above session close
            (dataframe['volume_ratio'] > 2.0) &         # Strong volume
            (dataframe['close'] > dataframe['open']) &  # Green candle
            (dataframe['rsi'] > 50) & (dataframe['rsi'] < 75)  # Good RSI range
        )
        
        # === COMBINE ONLY PREMIUM SETUPS ===
        premium_setups = (
            enhanced_sweep_reversal | enhanced_momentum_breakout | 
            enhanced_trend_continuation | premium_session_momentum
        )
        
        # === ENHANCED ENTRY CONDITION (All Quality Gates + Premium Setups) ===
        enhanced_entry = (
            momentum_ok & 
            volume_ok & 
            volatility_ok & 
            trend_ok &
            session_ok &      # Session filter always required
            premium_setups    # Only premium quality setups
        )
        
        dataframe.loc[enhanced_entry, "enter_long"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        ENHANCED ROI-ONLY STRATEGY: No custom exit signals
        Let enhanced ROI ladder handle all exits with higher targets
        """
        return dataframe

    # === NO CUSTOM EXIT LOGIC - ROI-ONLY FOR SIMPLICITY ===
    # Enhanced ROI ladder does all the work with higher profit targets

# === ENHANCED STRATEGY TARGETS FOR 3% MONTHLY ===
"""
🎯 ENHANCED STRATEGY FOR 3% MONTHLY RETURNS:

CURRENT PERFORMANCE ANALYSIS:
- ROI-only v6: +0.28% over 6 months
- Best month: April +0.86%
- Need 3.5x improvement for 3% monthly target

ENHANCEMENT APPROACH:
1. Higher ROI targets: 2.0%/1.5%/1.0% (vs 1.2%/0.8%/0.4%)
2. Quality over quantity: Tighter entry filters
3. Enhanced setups: Premium momentum + volume confirmation
4. Faster profit taking: 20min vs 30min, 1h vs 2h

🏆 EXPECTED RESULTS:
- Fewer but higher quality trades
- Higher average profit per trade
- Better risk/reward with tighter stoploss
- Target: 3% monthly = 36% annual compound

📊 SUCCESS METRICS:
✅ 3% monthly return target
✅ Higher profit per trade (target 1-2% avg)
✅ Maintained high win rate (target 80%+)
✅ Controlled drawdown (<5%)
✅ Consistent monthly performance

🏆 MISSION: SYSTEMATIC 3% MONTHLY RETURNS!
""" 